define('GlobalSettings', [], function () {
    return (function () {
        'use strict';
        var __webpack_require__ = {
                d: function (exports, definition) {
                    for (var key in definition)
                        __webpack_require__.o(definition, key) &&
                            !__webpack_require__.o(exports, key) &&
                            Object.defineProperty(exports, key, { enumerable: !0, get: definition[key] });
                },
                o: function (obj, prop) {
                    return Object.prototype.hasOwnProperty.call(obj, prop);
                },
                r: function (exports) {
                    'undefined' != typeof Symbol &&
                        Symbol.toStringTag &&
                        Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' }),
                        Object.defineProperty(exports, '__esModule', { value: !0 });
                },
            },
            __webpack_exports__ = {};
        __webpack_require__.r(__webpack_exports__),
            __webpack_require__.d(__webpack_exports__, {
                WidgetGlobalSettings: function () {
                    return WidgetGlobalSettings;
                },
            });
        const WidgetGlobalSettings = () => null;
        return __webpack_exports__;
    })();
});
