/*! For license information please see Content.js.LICENSE.txt */
define('Content', ['react', '@lumx/react', 'axios', 'lumapps-sdk-js'], function (
    __WEBPACK_EXTERNAL_MODULE__959__,
    __WEBPACK_EXTERNAL_MODULE__482__,
    __WEBPACK_EXTERNAL_MODULE__386__,
    __WEBPACK_EXTERNAL_MODULE__441__,
) {
    return (function () {
        'use strict';
        function __webpack_require__(moduleId) {
            var cachedModule = __webpack_module_cache__[moduleId];
            if (void 0 !== cachedModule) return cachedModule.exports;
            var module = (__webpack_module_cache__[moduleId] = { id: moduleId, exports: {} });
            return __webpack_modules__[moduleId](module, module.exports, __webpack_require__), module.exports;
        }
        var deferred,
            __webpack_modules__ = {
                738: function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
                    function shallowEqual(objA, objB) {
                        if (objA === objB) return !0;
                        if (!objA || !objB) return !1;
                        var aKeys = Object.keys(objA),
                            bKeys = Object.keys(objB),
                            len = aKeys.length;
                        if (bKeys.length !== len) return !1;
                        for (var i = 0; i < len; i++) {
                            var key = aKeys[i];
                            if (objA[key] !== objB[key] || !Object.prototype.hasOwnProperty.call(objB, key)) return !1;
                        }
                        return !0;
                    }
                    function processIntlConfig(config) {
                        return {
                            locale: config.locale,
                            timeZone: config.timeZone,
                            fallbackOnEmptyString: config.fallbackOnEmptyString,
                            formats: config.formats,
                            textComponent: config.textComponent,
                            messages: config.messages,
                            defaultLocale: config.defaultLocale,
                            defaultFormats: config.defaultFormats,
                            onError: config.onError,
                            wrapRichTextChunksInFragment: config.wrapRichTextChunksInFragment,
                            defaultRichTextElements: config.defaultRichTextElements,
                        };
                    }
                    function assignUniqueKeysToFormatXMLElementFnArgument(values) {
                        return values
                            ? Object.keys(values).reduce(function (acc, k) {
                                  var formatXMLElementFn,
                                      v = values[k];
                                  return (
                                      (acc[k] = (0, formatters.c)(v)
                                          ? ((formatXMLElementFn = v),
                                            function (parts) {
                                                return formatXMLElementFn(external_react_.Children.toArray(parts));
                                            })
                                          : v),
                                      acc
                                  );
                              }, {})
                            : values;
                    }
                    __webpack_require__.r(__webpack_exports__),
                        __webpack_require__.d(__webpack_exports__, {
                            Widget: function () {
                                return NotificationAwareWidget;
                            },
                        });
                    var external_react_ = __webpack_require__(959),
                        external_react_default = __webpack_require__.n(external_react_),
                        tslib_es6 = __webpack_require__(827),
                        IntlContext = (__webpack_require__(146), external_react_.createContext(null)),
                        IntlProvider = (IntlContext.Consumer, IntlContext.Provider),
                        Provider = IntlProvider,
                        utils = __webpack_require__(672),
                        src_utils = __webpack_require__(683),
                        DEFAULT_INTL_CONFIG = (0, tslib_es6.a)((0, tslib_es6.a)({}, src_utils.a), {
                            textComponent: external_react_.Fragment,
                        }),
                        message = __webpack_require__(205),
                        create_intl = __webpack_require__(842),
                        formatters = __webpack_require__(71),
                        formatMessage = function (config, formatters, descriptor, rawValues) {
                            for (var rest = [], _i = 4; _i < arguments.length; _i++) rest[_i - 4] = arguments[_i];
                            var values = assignUniqueKeysToFormatXMLElementFnArgument(rawValues),
                                chunks = message.a.apply(
                                    void 0,
                                    (0, tslib_es6.d)([config, formatters, descriptor, values], rest, !1),
                                );
                            return Array.isArray(chunks) ? external_react_.Children.toArray(chunks) : chunks;
                        },
                        createIntl = function (_a, cache) {
                            var rawDefaultRichTextElements = _a.defaultRichTextElements,
                                config = (0, tslib_es6.c)(_a, ['defaultRichTextElements']),
                                defaultRichTextElements =
                                    assignUniqueKeysToFormatXMLElementFnArgument(rawDefaultRichTextElements),
                                coreIntl = (0, create_intl.a)(
                                    (0, tslib_es6.a)(
                                        (0, tslib_es6.a)((0, tslib_es6.a)({}, DEFAULT_INTL_CONFIG), config),
                                        { defaultRichTextElements: defaultRichTextElements },
                                    ),
                                    cache,
                                );
                            return (0, tslib_es6.a)((0, tslib_es6.a)({}, coreIntl), {
                                formatMessage: formatMessage.bind(
                                    null,
                                    {
                                        locale: coreIntl.locale,
                                        timeZone: coreIntl.timeZone,
                                        formats: coreIntl.formats,
                                        defaultLocale: coreIntl.defaultLocale,
                                        defaultFormats: coreIntl.defaultFormats,
                                        messages: coreIntl.messages,
                                        onError: coreIntl.onError,
                                        defaultRichTextElements: defaultRichTextElements,
                                    },
                                    coreIntl.formatters,
                                ),
                            });
                        },
                        provider_IntlProvider = (function (_super) {
                            function IntlProvider() {
                                var _this = (null !== _super && _super.apply(this, arguments)) || this;
                                return (
                                    (_this.cache = (0, src_utils.c)()),
                                    (_this.state = {
                                        cache: _this.cache,
                                        intl: createIntl(processIntlConfig(_this.props), _this.cache),
                                        prevConfig: processIntlConfig(_this.props),
                                    }),
                                    _this
                                );
                            }
                            return (
                                (0, tslib_es6.b)(IntlProvider, _super),
                                (IntlProvider.getDerivedStateFromProps = function (props, _a) {
                                    var prevConfig = _a.prevConfig,
                                        cache = _a.cache,
                                        config = processIntlConfig(props);
                                    return shallowEqual(prevConfig, config)
                                        ? null
                                        : { intl: createIntl(config, cache), prevConfig: config };
                                }),
                                (IntlProvider.prototype.render = function () {
                                    var intl;
                                    return (
                                        (intl = this.state.intl),
                                        (0, utils.a)(
                                            intl,
                                            '[React Intl] Could not find required `intl` object. <IntlProvider> needs to exist in the component ancestry.',
                                        ),
                                        external_react_.createElement(
                                            Provider,
                                            { value: this.state.intl },
                                            this.props.children,
                                        )
                                    );
                                }),
                                (IntlProvider.displayName = 'IntlProvider'),
                                (IntlProvider.defaultProps = DEFAULT_INTL_CONFIG),
                                IntlProvider
                            );
                        })(external_react_.PureComponent),
                        provider = provider_IntlProvider;
                    const mdiEmail =
                        'm20 8-8 5-8-5V6l8 5 8-5m0-2H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2';
                    var react_ = __webpack_require__(482),
                        external_axios_ = __webpack_require__(386),
                        external_axios_default = __webpack_require__.n(external_axios_),
                        external_lumapps_sdk_js_ = __webpack_require__(441),
                        en_namespaceObject = JSON.parse(
                            '{"title":"Lorem Picsum","sub_title":"Sample widget","description":"This is a tiny example of all the things you can do with a LumApps widget","errors.retrieve_user":"An error occurred while retrieving user","errors.dismiss":"Dismiss","settings.image_id":"Image identifier","settings.grey":"Display a grey scale image","settings.blur":"Display a blurry image","settings.blur_value_title":"Blur value","settings.blur_value_desc":"Adjust blue effect"}',
                        ),
                        fr_namespaceObject = JSON.parse(
                            '{"title":"Lorem Picsum","sub_title":"Exemple de widget","description":"Ceci est un petit exemple de ce qu\'il est possible de faire avec les widgets LumApps","errors.retrieve_user":"Une erreur est survenue au moment de récupérer l\'utilisateur","errors.dismiss":"Fermer","settings.image_id":"ID de l\'image","settings.grey":"Noir et blanc","settings.blur":"Flou","settings.blur_value_title":"Valeur du flou","settings.blur_value_desc":"Ajuster la valeur du flou"}',
                        ),
                        injectStylesIntoStyleTag = __webpack_require__(691),
                        injectStylesIntoStyleTag_default = __webpack_require__.n(injectStylesIntoStyleTag),
                        styleDomAPI = __webpack_require__(825),
                        styleDomAPI_default = __webpack_require__.n(styleDomAPI),
                        insertBySelector = __webpack_require__(659),
                        insertBySelector_default = __webpack_require__.n(insertBySelector),
                        setAttributesWithoutAttributes = __webpack_require__(56),
                        setAttributesWithoutAttributes_default = __webpack_require__.n(setAttributesWithoutAttributes),
                        insertStyleElement = __webpack_require__(540),
                        insertStyleElement_default = __webpack_require__.n(insertStyleElement),
                        styleTagTransform = __webpack_require__(113),
                        styleTagTransform_default = __webpack_require__.n(styleTagTransform),
                        Widget = __webpack_require__(612),
                        options = {};
                    (options.styleTagTransform = styleTagTransform_default()),
                        (options.setAttributes = setAttributesWithoutAttributes_default()),
                        (options.insert = insertBySelector_default().bind(null, 'head')),
                        (options.domAPI = styleDomAPI_default()),
                        (options.insertStyleElement = insertStyleElement_default());
                    injectStylesIntoStyleTag_default()(Widget.a, options),
                        Widget.a && Widget.a.locals && Widget.a.locals;
                    const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
                        Widget_Widget = (_ref) => {
                            let { theme: theme = react_.Theme.light } = _ref;
                            const [lastName, setLastName] = (0, external_react_.useState)(''),
                                [dob, setDob] = (0, external_react_.useState)(void 0),
                                [email, setEmail] = (0, external_react_.useState)(''),
                                [confirmEmail, setConfirmEmail] = (0, external_react_.useState)(''),
                                [employeeId, setEmployeeId] = (0, external_react_.useState)(''),
                                [submitted, setSubmitted] = (0, external_react_.useState)(!1),
                                [isSubmitting, setIsSubmitting] = (0, external_react_.useState)(!1),
                                [apiError, setApiError] = (0, external_react_.useState)(),
                                [isSuccess, setIsSuccess] = (0, external_react_.useState)(!1);
                            (0, external_lumapps_sdk_js_.useNotifications)();
                            const context = (0, external_lumapps_sdk_js_.useContext)(),
                                organization = (0, external_lumapps_sdk_js_.useOrganization)(),
                                apiEndpoint = ''
                                    .concat(null == context ? void 0 : context.haussmannCell, '/v2/organizations/')
                                    .concat(
                                        null == organization ? void 0 : organization.id,
                                        '/self-onboardings/magic-links',
                                    ),
                                lastNameError = submitted && !lastName.trim() ? 'Last name is required' : void 0,
                                dobError = submitted && !dob ? 'Date of birth is required' : void 0,
                                employeeIdError = submitted && !employeeId.trim() ? 'Employee ID is required' : void 0,
                                emailError =
                                    !submitted || (email && EMAIL_PATTERN.test(email))
                                        ? void 0
                                        : 'A valid email address is required';
                            let confirmEmailError;
                            submitted &&
                                (confirmEmail.trim()
                                    ? confirmEmail !== email && (confirmEmailError = 'Email addresses do not match')
                                    : (confirmEmailError = 'Please confirm your email address'));
                            const isValid =
                                    !!lastName.trim() &&
                                    !!dob &&
                                    !!employeeId.trim() &&
                                    EMAIL_PATTERN.test(email) &&
                                    confirmEmail === email,
                                handleSubmit = async (e) => {
                                    if ((e.preventDefault(), setSubmitted(!0), !isValid)) return;
                                    setIsSubmitting(!0), setApiError(void 0);
                                    const payload = {
                                        lastName: lastName.trim(),
                                        dateOfBirth:
                                            ((d = dob),
                                            ''
                                                .concat(d.getFullYear(), '-')
                                                .concat(String(d.getMonth() + 1).padStart(2, '0'), '-')
                                                .concat(String(d.getDate()).padStart(2, '0'))),
                                        employeeId: employeeId.trim(),
                                        email: email,
                                    };
                                    var d;
                                    try {
                                        console.log('POST', apiEndpoint, payload),
                                            await external_axios_default().post(apiEndpoint, payload),
                                            setIsSuccess(!0);
                                    } catch (err) {
                                        var _err$response;
                                        const detail =
                                            (external_axios_default().isAxiosError(err) &&
                                                (null === (_err$response = err.response) ||
                                                void 0 === _err$response ||
                                                null === (_err$response = _err$response.data) ||
                                                void 0 === _err$response ||
                                                null === (_err$response = _err$response.errors) ||
                                                void 0 === _err$response ||
                                                null === (_err$response = _err$response[0]) ||
                                                void 0 === _err$response
                                                    ? void 0
                                                    : _err$response.detail)) ||
                                            'Submission failed. Lorem ipsum dolor sit amet.';
                                        setApiError(detail);
                                    } finally {
                                        setIsSubmitting(!1);
                                    }
                                };
                            return isSuccess
                                ? external_react_default().createElement(
                                      'div',
                                      { className: 'registration-form__success' },
                                      external_react_default().createElement(
                                          'h1',
                                          {
                                              className:
                                                  'registration-form__success-title lumx-typography-custom-title3 ',
                                          },
                                          "Success! You're all set.",
                                      ),
                                      external_react_default().createElement(
                                          'p',
                                          { className: 'registration-form__success-body' },
                                          'Your account is ready. Follow these Steps to log in:',
                                      ),
                                      external_react_default().createElement(
                                          'ul',
                                          null,
                                          external_react_default().createElement(
                                              'li',
                                              { className: 'lumx-spacing-margin-bottom-huge' },
                                              external_react_default().createElement('strong', null, 'Step 1:'),
                                              ' Click the button below to go to the login screen.',
                                          ),
                                          external_react_default().createElement(
                                              'li',
                                              { className: 'lumx-spacing-margin-bottom-huge' },
                                              external_react_default().createElement('strong', null, 'Step 2:'),
                                              ' Select ',
                                              external_react_default().createElement(
                                                  'strong',
                                                  null,
                                                  '“Sign in with email link”',
                                              ),
                                              '.',
                                          ),
                                          external_react_default().createElement(
                                              'li',
                                              null,
                                              external_react_default().createElement('strong', null, 'Step 3:'),
                                              ' Enter your email ',
                                              external_react_default().createElement('strong', null, '(', email, ')'),
                                              ' to receive your secure entry link.',
                                          ),
                                      ),
                                      external_react_default().createElement(
                                          'p',
                                          { className: 'lumx-typography-caption' },
                                          external_react_default().createElement(
                                              'em',
                                              null,
                                              'Not your email?',
                                              ' ',
                                              external_react_default().createElement(
                                                  'button',
                                                  {
                                                      type: 'button',
                                                      className: 'registration-form__reset-link',
                                                      onClick: () => {
                                                          setLastName(''),
                                                              setDob(void 0),
                                                              setEmployeeId(''),
                                                              setEmail(''),
                                                              setConfirmEmail(''),
                                                              setSubmitted(!1),
                                                              setIsSuccess(!1);
                                                      },
                                                  },
                                                  'Use a different email address',
                                              ),
                                          ),
                                          '.',
                                      ),
                                      external_react_default().createElement(
                                          'a',
                                          { href: 'YOUR_LOGIN_URL', className: 'registration-form__success-action' },
                                          external_react_default().createElement(
                                              react_.Button,
                                              { theme: theme, size: react_.Size.m },
                                              'Proceed to Login',
                                          ),
                                      ),
                                  )
                                : external_react_default().createElement(
                                      'form',
                                      { className: 'registration-form', onSubmit: handleSubmit },
                                      external_react_default().createElement(
                                          'h1',
                                          { className: 'lumx-typography-custom-title3' },
                                          'Enter your details',
                                      ),
                                      external_react_default().createElement(
                                          'div',
                                          null,
                                          external_react_default().createElement(react_.TextField, {
                                              label: 'Last name',
                                              value: lastName,
                                              onChange: setLastName,
                                              hasError: !!lastNameError,
                                              helper: lastNameError,
                                              icon: 'M12 4a4 4 0 0 1 4 4 4 4 0 0 1-4 4 4 4 0 0 1-4-4 4 4 0 0 1 4-4m0 10c4.42 0 8 1.79 8 4v2H4v-2c0-2.21 3.58-4 8-4',
                                              isRequired: !0,
                                              theme: theme,
                                              className: '',
                                          }),
                                          external_react_default().createElement(react_.DatePickerField, {
                                              locale: 'en',
                                              label: 'Date of birth',
                                              icon: 'M19 19H5V8h14m-3-7v2H8V1H6v2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2h-1V1m-1 11h-5v5h5z',
                                              value: dob,
                                              onChange: setDob,
                                              hasError: !!dobError,
                                              helper: dobError,
                                              isRequired: !0,
                                              theme: theme,
                                              nextButtonProps: { label: 'Next month' },
                                              previousButtonProps: { label: 'Previous month' },
                                          }),
                                          external_react_default().createElement(react_.TextField, {
                                              label: 'Employee ID',
                                              value: employeeId,
                                              onChange: setEmployeeId,
                                              hasError: !!employeeIdError,
                                              helper: employeeIdError,
                                              icon: 'M2 3h20c1.05 0 2 .95 2 2v14c0 1.05-.95 2-2 2H2c-1.05 0-2-.95-2-2V5c0-1.05.95-2 2-2m12 3v1h8V6zm0 2v1h8V8zm0 2v1h7v-1zm-6 3.91C6 13.91 2 15 2 17v1h12v-1c0-2-4-3.09-6-3.09M8 6a3 3 0 0 0-3 3 3 3 0 0 0 3 3 3 3 0 0 0 3-3 3 3 0 0 0-3-3',
                                              isRequired: !0,
                                              theme: theme,
                                              className: '',
                                          }),
                                          external_react_default().createElement(react_.TextField, {
                                              label: 'Email',
                                              value: email,
                                              onChange: setEmail,
                                              hasError: !!emailError,
                                              helper: emailError,
                                              icon: mdiEmail,
                                              isRequired: !0,
                                              theme: theme,
                                              className: '',
                                          }),
                                          external_react_default().createElement(
                                              'div',
                                              { onPaste: (e) => e.preventDefault() },
                                              external_react_default().createElement(react_.TextField, {
                                                  label: 'Confirm email',
                                                  value: confirmEmail,
                                                  onChange: setConfirmEmail,
                                                  hasError: !!confirmEmailError,
                                                  helper: confirmEmailError,
                                                  icon: mdiEmail,
                                                  isRequired: !0,
                                                  theme: theme,
                                                  className: '',
                                              }),
                                          ),
                                          apiError &&
                                              external_react_default().createElement(
                                                  react_.Message,
                                                  { kind: 'error', hasBackground: !0 },
                                                  external_react_default().createElement('p', null, apiError),
                                              ),
                                          external_react_default().createElement(
                                              'div',
                                              { className: 'registration-form__submit ' },
                                              external_react_default().createElement(
                                                  react_.Button,
                                                  {
                                                      onClick: handleSubmit,
                                                      isDisabled: isSubmitting,
                                                      theme: theme,
                                                      size: react_.Size.m,
                                                      className: 'lumx-color-background-primary-N',
                                                  },
                                                  isSubmitting ? 'Submitting…' : 'Submit',
                                              ),
                                          ),
                                      ),
                                  );
                        },
                        NotificationAwareWidget = (props) => {
                            const { displayLanguage: displayLanguage } = (0, external_lumapps_sdk_js_.useLanguage)(),
                                messages = (0, external_react_.useMemo)(
                                    () => ({ en: en_namespaceObject, fr: fr_namespaceObject }),
                                    [],
                                );
                            console.log('messages', messages);
                            const lang = (0, external_react_.useMemo)(
                                () => (Object.keys(messages).includes(displayLanguage) ? displayLanguage : 'en'),
                                [displayLanguage, messages],
                            );
                            return external_react_default().createElement(
                                provider,
                                { locale: lang, messages: messages[lang] },
                                external_react_default().createElement(
                                    external_lumapps_sdk_js_.NotificationsProvider,
                                    null,
                                    external_react_default().createElement(
                                        external_lumapps_sdk_js_.PredefinedErrorBoundary,
                                        null,
                                        external_react_default().createElement(Widget_Widget, props),
                                    ),
                                ),
                            );
                        };
                },
                612: function (module, __webpack_exports__, __webpack_require__) {
                    var _node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ =
                            __webpack_require__(601),
                        _node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default =
                            __webpack_require__.n(
                                _node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_0__,
                            ),
                        _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ =
                            __webpack_require__(314),
                        _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default =
                            __webpack_require__.n(
                                _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__,
                            ),
                        ___CSS_LOADER_EXPORT___ =
                            _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()(
                                _node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default(),
                            );
                    ___CSS_LOADER_EXPORT___.push([
                        module.id,
                        '.registration-form__captcha {\n    display: flex;\n    justify-content: center;\n}\n\n.registration-form__submit {\n    display: flex;\n    justify-content: center;\n}\n\n.registration-form__success {\n    display: flex;\n    flex-direction: column;\n\n    padding: 24px;\n    gap: 24px;\n}\n\n.registration-form {\n    display: flex;\n    flex-direction: column;\n\n    padding: 24px;\n    gap: 24px;\n}\n\n.registration-form > div {\n    display: flex;\n    flex-direction: column;\n\n    gap: 24px;\n}\n\n.registration-form__success-title {\n    margin: 0;\n}\n\n.registration-form__success-body {\n    margin: 0;\n}\n\n.registration-form__success-action {\n    align-self: center;\n    text-decoration: none;\n}\n\n.registration-form__dev-tools {\n    display: flex;\n    flex-direction: column;\n    gap: 8px;\n    padding: 12px 16px;\n    border: 2px dashed orange;\n    border-radius: 4px;\n}\n\n.registration-form__dev-tools-label {\n    margin: 0;\n    font-size: 12px;\n    font-weight: 600;\n    color: orange;\n}\n\n.registration-form__reset-link {\n    background: none;\n    border: none;\n    padding: 0;\n    cursor: pointer;\n    text-decoration: underline;\n    font: inherit;\n    color: var(--lumx-color-primary-N);\n}\n\nul {\n    margin-inline-start: 24px;\n}\n\n.registration-form .theme-lumapps .lumx-select,\n.registration-form .theme-lumapps .lumx-text-field {\n    padding-bottom: 0;\n    padding-top: 0;\n}\n',
                        '',
                    ]),
                        (__webpack_exports__.a = ___CSS_LOADER_EXPORT___);
                },
                314: function (module) {
                    module.exports = function (cssWithMappingToString) {
                        var list = [];
                        return (
                            (list.toString = function () {
                                return this.map(function (item) {
                                    var content = '',
                                        needLayer = void 0 !== item[5];
                                    return (
                                        item[4] && (content += '@supports ('.concat(item[4], ') {')),
                                        item[2] && (content += '@media '.concat(item[2], ' {')),
                                        needLayer &&
                                            (content += '@layer'.concat(
                                                item[5].length > 0 ? ' '.concat(item[5]) : '',
                                                ' {',
                                            )),
                                        (content += cssWithMappingToString(item)),
                                        needLayer && (content += '}'),
                                        item[2] && (content += '}'),
                                        item[4] && (content += '}'),
                                        content
                                    );
                                }).join('');
                            }),
                            (list.i = function (modules, media, dedupe, supports, layer) {
                                'string' == typeof modules && (modules = [[null, modules, void 0]]);
                                var alreadyImportedModules = {};
                                if (dedupe)
                                    for (var k = 0; k < this.length; k++) {
                                        var id = this[k][0];
                                        null != id && (alreadyImportedModules[id] = !0);
                                    }
                                for (var _k = 0; _k < modules.length; _k++) {
                                    var item = [].concat(modules[_k]);
                                    (dedupe && alreadyImportedModules[item[0]]) ||
                                        (void 0 !== layer &&
                                            (void 0 === item[5] ||
                                                (item[1] = '@layer'
                                                    .concat(item[5].length > 0 ? ' '.concat(item[5]) : '', ' {')
                                                    .concat(item[1], '}')),
                                            (item[5] = layer)),
                                        media &&
                                            (item[2]
                                                ? ((item[1] = '@media '.concat(item[2], ' {').concat(item[1], '}')),
                                                  (item[2] = media))
                                                : (item[2] = media)),
                                        supports &&
                                            (item[4]
                                                ? ((item[1] = '@supports ('
                                                      .concat(item[4], ') {')
                                                      .concat(item[1], '}')),
                                                  (item[4] = supports))
                                                : (item[4] = ''.concat(supports))),
                                        list.push(item));
                                }
                            }),
                            list
                        );
                    };
                },
                601: function (module) {
                    module.exports = function (i) {
                        return i[1];
                    };
                },
                146: function (module, __unused_webpack_exports, __webpack_require__) {
                    function getStatics(component) {
                        return reactIs.isMemo(component)
                            ? MEMO_STATICS
                            : TYPE_STATICS[component.$$typeof] || REACT_STATICS;
                    }
                    var reactIs = __webpack_require__(404),
                        REACT_STATICS = {
                            childContextTypes: !0,
                            contextType: !0,
                            contextTypes: !0,
                            defaultProps: !0,
                            displayName: !0,
                            getDefaultProps: !0,
                            getDerivedStateFromError: !0,
                            getDerivedStateFromProps: !0,
                            mixins: !0,
                            propTypes: !0,
                            type: !0,
                        },
                        KNOWN_STATICS = {
                            name: !0,
                            length: !0,
                            prototype: !0,
                            caller: !0,
                            callee: !0,
                            arguments: !0,
                            arity: !0,
                        },
                        MEMO_STATICS = {
                            $$typeof: !0,
                            compare: !0,
                            defaultProps: !0,
                            displayName: !0,
                            propTypes: !0,
                            type: !0,
                        },
                        TYPE_STATICS = {};
                    (TYPE_STATICS[reactIs.ForwardRef] = {
                        $$typeof: !0,
                        render: !0,
                        defaultProps: !0,
                        displayName: !0,
                        propTypes: !0,
                    }),
                        (TYPE_STATICS[reactIs.Memo] = MEMO_STATICS);
                    var defineProperty = Object.defineProperty,
                        getOwnPropertyNames = Object.getOwnPropertyNames,
                        getOwnPropertySymbols = Object.getOwnPropertySymbols,
                        getOwnPropertyDescriptor = Object.getOwnPropertyDescriptor,
                        getPrototypeOf = Object.getPrototypeOf,
                        objectPrototype = Object.prototype;
                    module.exports = function hoistNonReactStatics(targetComponent, sourceComponent, blacklist) {
                        if ('string' != typeof sourceComponent) {
                            if (objectPrototype) {
                                var inheritedComponent = getPrototypeOf(sourceComponent);
                                inheritedComponent &&
                                    inheritedComponent !== objectPrototype &&
                                    hoistNonReactStatics(targetComponent, inheritedComponent, blacklist);
                            }
                            var keys = getOwnPropertyNames(sourceComponent);
                            getOwnPropertySymbols && (keys = keys.concat(getOwnPropertySymbols(sourceComponent)));
                            for (
                                var targetStatics = getStatics(targetComponent),
                                    sourceStatics = getStatics(sourceComponent),
                                    i = 0;
                                i < keys.length;
                                ++i
                            ) {
                                var key = keys[i];
                                if (
                                    !(
                                        KNOWN_STATICS[key] ||
                                        (blacklist && blacklist[key]) ||
                                        (sourceStatics && sourceStatics[key]) ||
                                        (targetStatics && targetStatics[key])
                                    )
                                ) {
                                    var descriptor = getOwnPropertyDescriptor(sourceComponent, key);
                                    try {
                                        defineProperty(targetComponent, key, descriptor);
                                    } catch (e) {}
                                }
                            }
                        }
                        return targetComponent;
                    };
                },
                72: function (__unused_webpack_module, exports) {
                    function z(a) {
                        if ('object' == typeof a && null !== a) {
                            var u = a.$$typeof;
                            switch (u) {
                                case c:
                                    switch (((a = a.type), a)) {
                                        case l:
                                        case m:
                                        case e:
                                        case g:
                                        case f:
                                        case p:
                                            return a;
                                        default:
                                            switch (((a = a && a.$$typeof), a)) {
                                                case k:
                                                case n:
                                                case t:
                                                case r:
                                                case h:
                                                    return a;
                                                default:
                                                    return u;
                                            }
                                    }
                                case d:
                                    return u;
                            }
                        }
                    }
                    function A(a) {
                        return z(a) === m;
                    }
                    var b = 'function' == typeof Symbol && Symbol.for,
                        c = b ? Symbol.for('react.element') : 60103,
                        d = b ? Symbol.for('react.portal') : 60106,
                        e = b ? Symbol.for('react.fragment') : 60107,
                        f = b ? Symbol.for('react.strict_mode') : 60108,
                        g = b ? Symbol.for('react.profiler') : 60114,
                        h = b ? Symbol.for('react.provider') : 60109,
                        k = b ? Symbol.for('react.context') : 60110,
                        l = b ? Symbol.for('react.async_mode') : 60111,
                        m = b ? Symbol.for('react.concurrent_mode') : 60111,
                        n = b ? Symbol.for('react.forward_ref') : 60112,
                        p = b ? Symbol.for('react.suspense') : 60113,
                        q = b ? Symbol.for('react.suspense_list') : 60120,
                        r = b ? Symbol.for('react.memo') : 60115,
                        t = b ? Symbol.for('react.lazy') : 60116,
                        v = b ? Symbol.for('react.block') : 60121,
                        w = b ? Symbol.for('react.fundamental') : 60117,
                        x = b ? Symbol.for('react.responder') : 60118,
                        y = b ? Symbol.for('react.scope') : 60119;
                    (exports.AsyncMode = l),
                        (exports.ConcurrentMode = m),
                        (exports.ContextConsumer = k),
                        (exports.ContextProvider = h),
                        (exports.Element = c),
                        (exports.ForwardRef = n),
                        (exports.Fragment = e),
                        (exports.Lazy = t),
                        (exports.Memo = r),
                        (exports.Portal = d),
                        (exports.Profiler = g),
                        (exports.StrictMode = f),
                        (exports.Suspense = p),
                        (exports.isAsyncMode = function (a) {
                            return A(a) || z(a) === l;
                        }),
                        (exports.isConcurrentMode = A),
                        (exports.isContextConsumer = function (a) {
                            return z(a) === k;
                        }),
                        (exports.isContextProvider = function (a) {
                            return z(a) === h;
                        }),
                        (exports.isElement = function (a) {
                            return 'object' == typeof a && null !== a && a.$$typeof === c;
                        }),
                        (exports.isForwardRef = function (a) {
                            return z(a) === n;
                        }),
                        (exports.isFragment = function (a) {
                            return z(a) === e;
                        }),
                        (exports.isLazy = function (a) {
                            return z(a) === t;
                        }),
                        (exports.isMemo = function (a) {
                            return z(a) === r;
                        }),
                        (exports.isPortal = function (a) {
                            return z(a) === d;
                        }),
                        (exports.isProfiler = function (a) {
                            return z(a) === g;
                        }),
                        (exports.isStrictMode = function (a) {
                            return z(a) === f;
                        }),
                        (exports.isSuspense = function (a) {
                            return z(a) === p;
                        }),
                        (exports.isValidElementType = function (a) {
                            return (
                                'string' == typeof a ||
                                'function' == typeof a ||
                                a === e ||
                                a === m ||
                                a === g ||
                                a === f ||
                                a === p ||
                                a === q ||
                                ('object' == typeof a &&
                                    null !== a &&
                                    (a.$$typeof === t ||
                                        a.$$typeof === r ||
                                        a.$$typeof === h ||
                                        a.$$typeof === k ||
                                        a.$$typeof === n ||
                                        a.$$typeof === w ||
                                        a.$$typeof === x ||
                                        a.$$typeof === y ||
                                        a.$$typeof === v))
                            );
                        }),
                        (exports.typeOf = z);
                },
                404: function (module, __unused_webpack_exports, __webpack_require__) {
                    module.exports = __webpack_require__(72);
                },
                587: function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
                    function createFastMemoizeCache(store) {
                        return {
                            create: function () {
                                return {
                                    get: function (key) {
                                        return store[key];
                                    },
                                    set: function (key, value) {
                                        store[key] = value;
                                    },
                                };
                            },
                        };
                    }
                    __webpack_require__.d(__webpack_exports__, {
                        a: function () {
                            return IntlMessageFormat;
                        },
                    });
                    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(827),
                        _formatjs_icu_messageformat_parser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(361),
                        _formatjs_fast_memoize__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(819),
                        _formatters__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(71),
                        IntlMessageFormat = (function () {
                            function IntlMessageFormat(message, locales, overrideFormats, opts) {
                                var defaultConfig,
                                    configs,
                                    cache,
                                    _this = this;
                                if (
                                    (void 0 === locales && (locales = IntlMessageFormat.defaultLocale),
                                    (this.formatterCache = { number: {}, dateTime: {}, pluralRules: {} }),
                                    (this.format = function (values) {
                                        var parts = _this.formatToParts(values);
                                        if (1 === parts.length) return parts[0].value;
                                        var result = parts.reduce(function (all, part) {
                                            return (
                                                all.length &&
                                                part.type === _formatters__WEBPACK_IMPORTED_MODULE_3__.a.literal &&
                                                'string' == typeof all[all.length - 1]
                                                    ? (all[all.length - 1] += part.value)
                                                    : all.push(part.value),
                                                all
                                            );
                                        }, []);
                                        return result.length <= 1 ? result[0] || '' : result;
                                    }),
                                    (this.formatToParts = function (values) {
                                        return (0, _formatters__WEBPACK_IMPORTED_MODULE_3__.b)(
                                            _this.ast,
                                            _this.locales,
                                            _this.formatters,
                                            _this.formats,
                                            values,
                                            void 0,
                                            _this.message,
                                        );
                                    }),
                                    (this.resolvedOptions = function () {
                                        return { locale: Intl.NumberFormat.supportedLocalesOf(_this.locales)[0] };
                                    }),
                                    (this.getAst = function () {
                                        return _this.ast;
                                    }),
                                    'string' == typeof message)
                                ) {
                                    if (((this.message = message), !IntlMessageFormat.__parse))
                                        throw new TypeError(
                                            'IntlMessageFormat.__parse must be set to process `message` of type `string`',
                                        );
                                    this.ast = IntlMessageFormat.__parse(message, {
                                        ignoreTag: null == opts ? void 0 : opts.ignoreTag,
                                    });
                                } else this.ast = message;
                                if (!Array.isArray(this.ast))
                                    throw new TypeError('A message must be provided as a String or AST.');
                                (this.formats =
                                    ((defaultConfig = IntlMessageFormat.formats),
                                    (configs = overrideFormats),
                                    configs
                                        ? Object.keys(defaultConfig).reduce(
                                              function (all, k) {
                                                  var c1, c2;
                                                  return (
                                                      (all[k] =
                                                          ((c1 = defaultConfig[k]),
                                                          (c2 = configs[k]),
                                                          c2
                                                              ? (0, tslib__WEBPACK_IMPORTED_MODULE_0__.a)(
                                                                    (0, tslib__WEBPACK_IMPORTED_MODULE_0__.a)(
                                                                        (0, tslib__WEBPACK_IMPORTED_MODULE_0__.a)(
                                                                            {},
                                                                            c1 || {},
                                                                        ),
                                                                        c2 || {},
                                                                    ),
                                                                    Object.keys(c1).reduce(function (all, k) {
                                                                        return (
                                                                            (all[k] = (0,
                                                                            tslib__WEBPACK_IMPORTED_MODULE_0__.a)(
                                                                                (0,
                                                                                tslib__WEBPACK_IMPORTED_MODULE_0__.a)(
                                                                                    {},
                                                                                    c1[k],
                                                                                ),
                                                                                c2[k] || {},
                                                                            )),
                                                                            all
                                                                        );
                                                                    }, {}),
                                                                )
                                                              : c1)),
                                                      all
                                                  );
                                              },
                                              (0, tslib__WEBPACK_IMPORTED_MODULE_0__.a)({}, defaultConfig),
                                          )
                                        : defaultConfig)),
                                    (this.locales = locales),
                                    (this.formatters =
                                        (opts && opts.formatters) ||
                                        ((cache = this.formatterCache),
                                        void 0 === cache && (cache = { number: {}, dateTime: {}, pluralRules: {} }),
                                        {
                                            getNumberFormat: (0, _formatjs_fast_memoize__WEBPACK_IMPORTED_MODULE_2__.a)(
                                                function () {
                                                    for (var _a, args = [], _i = 0; _i < arguments.length; _i++)
                                                        args[_i] = arguments[_i];
                                                    return new ((_a = Intl.NumberFormat).bind.apply(
                                                        _a,
                                                        (0, tslib__WEBPACK_IMPORTED_MODULE_0__.d)([void 0], args, !1),
                                                    ))();
                                                },
                                                {
                                                    cache: createFastMemoizeCache(cache.number),
                                                    strategy:
                                                        _formatjs_fast_memoize__WEBPACK_IMPORTED_MODULE_2__.b.variadic,
                                                },
                                            ),
                                            getDateTimeFormat: (0,
                                            _formatjs_fast_memoize__WEBPACK_IMPORTED_MODULE_2__.a)(
                                                function () {
                                                    for (var _a, args = [], _i = 0; _i < arguments.length; _i++)
                                                        args[_i] = arguments[_i];
                                                    return new ((_a = Intl.DateTimeFormat).bind.apply(
                                                        _a,
                                                        (0, tslib__WEBPACK_IMPORTED_MODULE_0__.d)([void 0], args, !1),
                                                    ))();
                                                },
                                                {
                                                    cache: createFastMemoizeCache(cache.dateTime),
                                                    strategy:
                                                        _formatjs_fast_memoize__WEBPACK_IMPORTED_MODULE_2__.b.variadic,
                                                },
                                            ),
                                            getPluralRules: (0, _formatjs_fast_memoize__WEBPACK_IMPORTED_MODULE_2__.a)(
                                                function () {
                                                    for (var _a, args = [], _i = 0; _i < arguments.length; _i++)
                                                        args[_i] = arguments[_i];
                                                    return new ((_a = Intl.PluralRules).bind.apply(
                                                        _a,
                                                        (0, tslib__WEBPACK_IMPORTED_MODULE_0__.d)([void 0], args, !1),
                                                    ))();
                                                },
                                                {
                                                    cache: createFastMemoizeCache(cache.pluralRules),
                                                    strategy:
                                                        _formatjs_fast_memoize__WEBPACK_IMPORTED_MODULE_2__.b.variadic,
                                                },
                                            ),
                                        }));
                            }
                            return (
                                Object.defineProperty(IntlMessageFormat, 'defaultLocale', {
                                    get: function () {
                                        return (
                                            IntlMessageFormat.memoizedDefaultLocale ||
                                                (IntlMessageFormat.memoizedDefaultLocale =
                                                    new Intl.NumberFormat().resolvedOptions().locale),
                                            IntlMessageFormat.memoizedDefaultLocale
                                        );
                                    },
                                    enumerable: !1,
                                    configurable: !0,
                                }),
                                (IntlMessageFormat.memoizedDefaultLocale = null),
                                (IntlMessageFormat.__parse =
                                    _formatjs_icu_messageformat_parser__WEBPACK_IMPORTED_MODULE_1__.m),
                                (IntlMessageFormat.formats = {
                                    number: {
                                        integer: { maximumFractionDigits: 0 },
                                        currency: { style: 'currency' },
                                        percent: { style: 'percent' },
                                    },
                                    date: {
                                        short: { month: 'numeric', day: 'numeric', year: '2-digit' },
                                        medium: { month: 'short', day: 'numeric', year: 'numeric' },
                                        long: { month: 'long', day: 'numeric', year: 'numeric' },
                                        full: { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' },
                                    },
                                    time: {
                                        short: { hour: 'numeric', minute: 'numeric' },
                                        medium: { hour: 'numeric', minute: 'numeric', second: 'numeric' },
                                        long: {
                                            hour: 'numeric',
                                            minute: 'numeric',
                                            second: 'numeric',
                                            timeZoneName: 'short',
                                        },
                                        full: {
                                            hour: 'numeric',
                                            minute: 'numeric',
                                            second: 'numeric',
                                            timeZoneName: 'short',
                                        },
                                    },
                                }),
                                IntlMessageFormat
                            );
                        })();
                },
                732: function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
                    __webpack_require__.d(__webpack_exports__, {
                        a: function () {
                            return ErrorCode;
                        },
                        b: function () {
                            return FormatError;
                        },
                        c: function () {
                            return InvalidValueError;
                        },
                        d: function () {
                            return InvalidValueTypeError;
                        },
                        e: function () {
                            return MissingValueError;
                        },
                    });
                    var ErrorCode,
                        tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(827);
                    !(function (ErrorCode) {
                        (ErrorCode.MISSING_VALUE = 'MISSING_VALUE'),
                            (ErrorCode.INVALID_VALUE = 'INVALID_VALUE'),
                            (ErrorCode.MISSING_INTL_API = 'MISSING_INTL_API');
                    })(ErrorCode || (ErrorCode = {}));
                    var FormatError = (function (_super) {
                            function FormatError(msg, code, originalMessage) {
                                var _this = _super.call(this, msg) || this;
                                return (_this.code = code), (_this.originalMessage = originalMessage), _this;
                            }
                            return (
                                (0, tslib__WEBPACK_IMPORTED_MODULE_0__.b)(FormatError, _super),
                                (FormatError.prototype.toString = function () {
                                    return '[formatjs Error: '.concat(this.code, '] ').concat(this.message);
                                }),
                                FormatError
                            );
                        })(Error),
                        InvalidValueError = (function (_super) {
                            function InvalidValueError(variableId, value, options, originalMessage) {
                                return (
                                    _super.call(
                                        this,
                                        'Invalid values for "'
                                            .concat(variableId, '": "')
                                            .concat(value, '". Options are "')
                                            .concat(Object.keys(options).join('", "'), '"'),
                                        ErrorCode.INVALID_VALUE,
                                        originalMessage,
                                    ) || this
                                );
                            }
                            return (
                                (0, tslib__WEBPACK_IMPORTED_MODULE_0__.b)(InvalidValueError, _super), InvalidValueError
                            );
                        })(FormatError),
                        InvalidValueTypeError = (function (_super) {
                            function InvalidValueTypeError(value, type, originalMessage) {
                                return (
                                    _super.call(
                                        this,
                                        'Value for "'.concat(value, '" must be of type ').concat(type),
                                        ErrorCode.INVALID_VALUE,
                                        originalMessage,
                                    ) || this
                                );
                            }
                            return (
                                (0, tslib__WEBPACK_IMPORTED_MODULE_0__.b)(InvalidValueTypeError, _super),
                                InvalidValueTypeError
                            );
                        })(FormatError),
                        MissingValueError = (function (_super) {
                            function MissingValueError(variableId, originalMessage) {
                                return (
                                    _super.call(
                                        this,
                                        'The intl string context variable "'
                                            .concat(variableId, '" was not provided to the string "')
                                            .concat(originalMessage, '"'),
                                        ErrorCode.MISSING_VALUE,
                                        originalMessage,
                                    ) || this
                                );
                            }
                            return (
                                (0, tslib__WEBPACK_IMPORTED_MODULE_0__.b)(MissingValueError, _super), MissingValueError
                            );
                        })(FormatError);
                },
                71: function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
                    function mergeLiteral(parts) {
                        return parts.length < 2
                            ? parts
                            : parts.reduce(function (all, part) {
                                  var lastPart = all[all.length - 1];
                                  return (
                                      lastPart && lastPart.type === PART_TYPE.literal && part.type === PART_TYPE.literal
                                          ? (lastPart.value += part.value)
                                          : all.push(part),
                                      all
                                  );
                              }, []);
                    }
                    function isFormatXMLElementFn(el) {
                        return 'function' == typeof el;
                    }
                    function formatToParts(
                        els,
                        locales,
                        formatters,
                        formats,
                        values,
                        currentPluralValue,
                        originalMessage,
                    ) {
                        if (
                            1 === els.length &&
                            (0, _formatjs_icu_messageformat_parser__WEBPACK_IMPORTED_MODULE_0__.e)(els[0])
                        )
                            return [{ type: PART_TYPE.literal, value: els[0].value }];
                        for (var result = [], _i = 0, els_1 = els; _i < els_1.length; _i++) {
                            var el = els_1[_i];
                            if ((0, _formatjs_icu_messageformat_parser__WEBPACK_IMPORTED_MODULE_0__.e)(el))
                                result.push({ type: PART_TYPE.literal, value: el.value });
                            else if ((0, _formatjs_icu_messageformat_parser__WEBPACK_IMPORTED_MODULE_0__.i)(el))
                                'number' == typeof currentPluralValue &&
                                    result.push({
                                        type: PART_TYPE.literal,
                                        value: formatters.getNumberFormat(locales).format(currentPluralValue),
                                    });
                            else {
                                var varName = el.value;
                                if (!values || !(varName in values))
                                    throw new _error__WEBPACK_IMPORTED_MODULE_1__.e(varName, originalMessage);
                                var value = values[varName];
                                if ((0, _formatjs_icu_messageformat_parser__WEBPACK_IMPORTED_MODULE_0__.b)(el))
                                    (value && 'string' != typeof value && 'number' != typeof value) ||
                                        (value =
                                            'string' == typeof value || 'number' == typeof value ? String(value) : ''),
                                        result.push({
                                            type: 'string' == typeof value ? PART_TYPE.literal : PART_TYPE.object,
                                            value: value,
                                        });
                                else if ((0, _formatjs_icu_messageformat_parser__WEBPACK_IMPORTED_MODULE_0__.c)(el)) {
                                    var style =
                                        'string' == typeof el.style
                                            ? formats.date[el.style]
                                            : (0, _formatjs_icu_messageformat_parser__WEBPACK_IMPORTED_MODULE_0__.d)(
                                                    el.style,
                                                )
                                              ? el.style.parsedOptions
                                              : void 0;
                                    result.push({
                                        type: PART_TYPE.literal,
                                        value: formatters.getDateTimeFormat(locales, style).format(value),
                                    });
                                } else if ((0, _formatjs_icu_messageformat_parser__WEBPACK_IMPORTED_MODULE_0__.l)(el)) {
                                    style =
                                        'string' == typeof el.style
                                            ? formats.time[el.style]
                                            : (0, _formatjs_icu_messageformat_parser__WEBPACK_IMPORTED_MODULE_0__.d)(
                                                    el.style,
                                                )
                                              ? el.style.parsedOptions
                                              : void 0;
                                    result.push({
                                        type: PART_TYPE.literal,
                                        value: formatters.getDateTimeFormat(locales, style).format(value),
                                    });
                                } else if ((0, _formatjs_icu_messageformat_parser__WEBPACK_IMPORTED_MODULE_0__.f)(el)) {
                                    style =
                                        'string' == typeof el.style
                                            ? formats.number[el.style]
                                            : (0, _formatjs_icu_messageformat_parser__WEBPACK_IMPORTED_MODULE_0__.g)(
                                                    el.style,
                                                )
                                              ? el.style.parsedOptions
                                              : void 0;
                                    style && style.scale && (value *= style.scale || 1),
                                        result.push({
                                            type: PART_TYPE.literal,
                                            value: formatters.getNumberFormat(locales, style).format(value),
                                        });
                                } else {
                                    if ((0, _formatjs_icu_messageformat_parser__WEBPACK_IMPORTED_MODULE_0__.k)(el)) {
                                        var children = el.children,
                                            value_1 = el.value,
                                            formatFn = values[value_1];
                                        if (!isFormatXMLElementFn(formatFn))
                                            throw new _error__WEBPACK_IMPORTED_MODULE_1__.d(
                                                value_1,
                                                'function',
                                                originalMessage,
                                            );
                                        var parts = formatToParts(
                                                children,
                                                locales,
                                                formatters,
                                                formats,
                                                values,
                                                currentPluralValue,
                                            ),
                                            chunks = formatFn(
                                                parts.map(function (p) {
                                                    return p.value;
                                                }),
                                            );
                                        Array.isArray(chunks) || (chunks = [chunks]),
                                            result.push.apply(
                                                result,
                                                chunks.map(function (c) {
                                                    return {
                                                        type:
                                                            'string' == typeof c ? PART_TYPE.literal : PART_TYPE.object,
                                                        value: c,
                                                    };
                                                }),
                                            );
                                    }
                                    if ((0, _formatjs_icu_messageformat_parser__WEBPACK_IMPORTED_MODULE_0__.j)(el)) {
                                        var opt = el.options[value] || el.options.other;
                                        if (!opt)
                                            throw new _error__WEBPACK_IMPORTED_MODULE_1__.c(
                                                el.value,
                                                value,
                                                Object.keys(el.options),
                                                originalMessage,
                                            );
                                        result.push.apply(
                                            result,
                                            formatToParts(opt.value, locales, formatters, formats, values),
                                        );
                                    } else if (
                                        (0, _formatjs_icu_messageformat_parser__WEBPACK_IMPORTED_MODULE_0__.h)(el)
                                    ) {
                                        opt = el.options['='.concat(value)];
                                        if (!opt) {
                                            if (!Intl.PluralRules)
                                                throw new _error__WEBPACK_IMPORTED_MODULE_1__.b(
                                                    'Intl.PluralRules is not available in this environment.\nTry polyfilling it using "@formatjs/intl-pluralrules"\n',
                                                    _error__WEBPACK_IMPORTED_MODULE_1__.a.MISSING_INTL_API,
                                                    originalMessage,
                                                );
                                            var rule = formatters
                                                .getPluralRules(locales, { type: el.pluralType })
                                                .select(value - (el.offset || 0));
                                            opt = el.options[rule] || el.options.other;
                                        }
                                        if (!opt)
                                            throw new _error__WEBPACK_IMPORTED_MODULE_1__.c(
                                                el.value,
                                                value,
                                                Object.keys(el.options),
                                                originalMessage,
                                            );
                                        result.push.apply(
                                            result,
                                            formatToParts(
                                                opt.value,
                                                locales,
                                                formatters,
                                                formats,
                                                values,
                                                value - (el.offset || 0),
                                            ),
                                        );
                                    } else;
                                }
                            }
                        }
                        return mergeLiteral(result);
                    }
                    __webpack_require__.d(__webpack_exports__, {
                        a: function () {
                            return PART_TYPE;
                        },
                        b: function () {
                            return formatToParts;
                        },
                        c: function () {
                            return isFormatXMLElementFn;
                        },
                    });
                    var PART_TYPE,
                        _formatjs_icu_messageformat_parser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(361),
                        _error__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(732);
                    !(function (PART_TYPE) {
                        (PART_TYPE[(PART_TYPE.literal = 0)] = 'literal'),
                            (PART_TYPE[(PART_TYPE.object = 1)] = 'object');
                    })(PART_TYPE || (PART_TYPE = {}));
                },
                691: function (module) {
                    function getIndexByIdentifier(identifier) {
                        for (var result = -1, i = 0; i < stylesInDOM.length; i++)
                            if (stylesInDOM[i].identifier === identifier) {
                                result = i;
                                break;
                            }
                        return result;
                    }
                    function modulesToDom(list, options) {
                        for (var idCountMap = {}, identifiers = [], i = 0; i < list.length; i++) {
                            var item = list[i],
                                id = options.base ? item[0] + options.base : item[0],
                                count = idCountMap[id] || 0,
                                identifier = ''.concat(id, ' ').concat(count);
                            idCountMap[id] = count + 1;
                            var indexByIdentifier = getIndexByIdentifier(identifier),
                                obj = {
                                    css: item[1],
                                    media: item[2],
                                    sourceMap: item[3],
                                    supports: item[4],
                                    layer: item[5],
                                };
                            if (-1 !== indexByIdentifier)
                                stylesInDOM[indexByIdentifier].references++,
                                    stylesInDOM[indexByIdentifier].updater(obj);
                            else {
                                var updater = addElementStyle(obj, options);
                                (options.byIndex = i),
                                    stylesInDOM.splice(i, 0, {
                                        identifier: identifier,
                                        updater: updater,
                                        references: 1,
                                    });
                            }
                            identifiers.push(identifier);
                        }
                        return identifiers;
                    }
                    function addElementStyle(obj, options) {
                        var api = options.domAPI(options);
                        api.update(obj);
                        return function (newObj) {
                            if (newObj) {
                                if (
                                    newObj.css === obj.css &&
                                    newObj.media === obj.media &&
                                    newObj.sourceMap === obj.sourceMap &&
                                    newObj.supports === obj.supports &&
                                    newObj.layer === obj.layer
                                )
                                    return;
                                api.update((obj = newObj));
                            } else api.remove();
                        };
                    }
                    var stylesInDOM = [];
                    module.exports = function (list, options) {
                        (options = options || {}), (list = list || []);
                        var lastIdentifiers = modulesToDom(list, options);
                        return function (newList) {
                            newList = newList || [];
                            for (var i = 0; i < lastIdentifiers.length; i++) {
                                var identifier = lastIdentifiers[i],
                                    index = getIndexByIdentifier(identifier);
                                stylesInDOM[index].references--;
                            }
                            for (
                                var newLastIdentifiers = modulesToDom(newList, options), _i = 0;
                                _i < lastIdentifiers.length;
                                _i++
                            ) {
                                var _identifier = lastIdentifiers[_i],
                                    _index = getIndexByIdentifier(_identifier);
                                0 === stylesInDOM[_index].references &&
                                    (stylesInDOM[_index].updater(), stylesInDOM.splice(_index, 1));
                            }
                            lastIdentifiers = newLastIdentifiers;
                        };
                    };
                },
                659: function (module) {
                    function getTarget(target) {
                        if (void 0 === memo[target]) {
                            var styleTarget = document.querySelector(target);
                            if (window.HTMLIFrameElement && styleTarget instanceof window.HTMLIFrameElement)
                                try {
                                    styleTarget = styleTarget.contentDocument.head;
                                } catch (e) {
                                    styleTarget = null;
                                }
                            memo[target] = styleTarget;
                        }
                        return memo[target];
                    }
                    var memo = {};
                    module.exports = function (insert, style) {
                        var target = getTarget(insert);
                        if (!target)
                            throw new Error(
                                "Couldn't find a style target. This probably means that the value for the 'insert' parameter is invalid.",
                            );
                        target.appendChild(style);
                    };
                },
                540: function (module) {
                    module.exports = function (options) {
                        var element = document.createElement('style');
                        return (
                            options.setAttributes(element, options.attributes),
                            options.insert(element, options.options),
                            element
                        );
                    };
                },
                56: function (module, __unused_webpack_exports, __webpack_require__) {
                    module.exports = function (styleElement) {
                        var nonce = __webpack_require__.nc;
                        nonce && styleElement.setAttribute('nonce', nonce);
                    };
                },
                825: function (module) {
                    function apply(styleElement, options, obj) {
                        var css = '';
                        obj.supports && (css += '@supports ('.concat(obj.supports, ') {')),
                            obj.media && (css += '@media '.concat(obj.media, ' {'));
                        var needLayer = void 0 !== obj.layer;
                        needLayer && (css += '@layer'.concat(obj.layer.length > 0 ? ' '.concat(obj.layer) : '', ' {')),
                            (css += obj.css),
                            needLayer && (css += '}'),
                            obj.media && (css += '}'),
                            obj.supports && (css += '}');
                        var sourceMap = obj.sourceMap;
                        sourceMap &&
                            'undefined' != typeof btoa &&
                            (css += '\n/*# sourceMappingURL=data:application/json;base64,'.concat(
                                btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap)))),
                                ' */',
                            )),
                            options.styleTagTransform(css, styleElement, options.options);
                    }
                    function removeStyleElement(styleElement) {
                        if (null === styleElement.parentNode) return !1;
                        styleElement.parentNode.removeChild(styleElement);
                    }
                    module.exports = function (options) {
                        if ('undefined' == typeof document) return { update: function () {}, remove: function () {} };
                        var styleElement = options.insertStyleElement(options);
                        return {
                            update: function (obj) {
                                apply(styleElement, options, obj);
                            },
                            remove: function () {
                                removeStyleElement(styleElement);
                            },
                        };
                    };
                },
                113: function (module) {
                    module.exports = function (css, styleElement) {
                        if (styleElement.styleSheet) styleElement.styleSheet.cssText = css;
                        else {
                            for (; styleElement.firstChild; ) styleElement.removeChild(styleElement.firstChild);
                            styleElement.appendChild(document.createTextNode(css));
                        }
                    };
                },
                482: function (module) {
                    module.exports = __WEBPACK_EXTERNAL_MODULE__482__;
                },
                386: function (module) {
                    module.exports = __WEBPACK_EXTERNAL_MODULE__386__;
                },
                441: function (module) {
                    module.exports = __WEBPACK_EXTERNAL_MODULE__441__;
                },
                959: function (module) {
                    module.exports = __WEBPACK_EXTERNAL_MODULE__959__;
                },
                827: function (__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {
                    function __extends(d, b) {
                        function __() {
                            this.constructor = d;
                        }
                        if ('function' != typeof b && null !== b)
                            throw new TypeError('Class extends value ' + String(b) + ' is not a constructor or null');
                        extendStatics(d, b),
                            (d.prototype = null === b ? Object.create(b) : ((__.prototype = b.prototype), new __()));
                    }
                    function __rest(s, e) {
                        var t = {};
                        for (var p in s)
                            Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0 && (t[p] = s[p]);
                        if (null != s && 'function' == typeof Object.getOwnPropertySymbols) {
                            var i = 0;
                            for (p = Object.getOwnPropertySymbols(s); i < p.length; i++)
                                e.indexOf(p[i]) < 0 &&
                                    Object.prototype.propertyIsEnumerable.call(s, p[i]) &&
                                    (t[p[i]] = s[p[i]]);
                        }
                        return t;
                    }
                    function __spreadArray(to, from, pack) {
                        if (pack || 2 === arguments.length)
                            for (var ar, i = 0, l = from.length; i < l; i++)
                                (!ar && i in from) ||
                                    (ar || (ar = Array.prototype.slice.call(from, 0, i)), (ar[i] = from[i]));
                        return to.concat(ar || Array.prototype.slice.call(from));
                    }
                    __webpack_require__.d(__webpack_exports__, {
                        a: function () {
                            return __assign;
                        },
                        b: function () {
                            return __extends;
                        },
                        c: function () {
                            return __rest;
                        },
                        d: function () {
                            return __spreadArray;
                        },
                    });
                    var extendStatics = function (d, b) {
                            return (
                                (extendStatics =
                                    Object.setPrototypeOf ||
                                    ({ __proto__: [] } instanceof Array &&
                                        function (d, b) {
                                            d.__proto__ = b;
                                        }) ||
                                    function (d, b) {
                                        for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (d[p] = b[p]);
                                    }),
                                extendStatics(d, b)
                            );
                        },
                        __assign = function () {
                            return (
                                (__assign =
                                    Object.assign ||
                                    function (t) {
                                        for (var s, i = 1, n = arguments.length; i < n; i++)
                                            for (var p in ((s = arguments[i]), s))
                                                Object.prototype.hasOwnProperty.call(s, p) && (t[p] = s[p]);
                                        return t;
                                    }),
                                __assign.apply(this, arguments)
                            );
                        };
                    Object.create, Object.create, 'function' == typeof SuppressedError && SuppressedError;
                },
            },
            __webpack_module_cache__ = {};
        (__webpack_require__.m = __webpack_modules__),
            (deferred = []),
            (__webpack_require__.O = function (result, chunkIds, fn, priority) {
                if (!chunkIds) {
                    var notFulfilled = Infinity;
                    for (i = 0; i < deferred.length; i++) {
                        (chunkIds = deferred[i][0]), (fn = deferred[i][1]), (priority = deferred[i][2]);
                        for (var fulfilled = !0, j = 0; j < chunkIds.length; j++)
                            (!1 & priority || notFulfilled >= priority) &&
                            Object.keys(__webpack_require__.O).every(function (key) {
                                return __webpack_require__.O[key](chunkIds[j]);
                            })
                                ? chunkIds.splice(j--, 1)
                                : ((fulfilled = !1), priority < notFulfilled && (notFulfilled = priority));
                        if (fulfilled) {
                            deferred.splice(i--, 1);
                            var r = fn();
                            void 0 !== r && (result = r);
                        }
                    }
                    return result;
                }
                priority = priority || 0;
                for (var i = deferred.length; i > 0 && deferred[i - 1][2] > priority; i--)
                    deferred[i] = deferred[i - 1];
                deferred[i] = [chunkIds, fn, priority];
            }),
            (__webpack_require__.n = function (module) {
                var getter =
                    module && module.__esModule
                        ? function () {
                              return module.default;
                          }
                        : function () {
                              return module;
                          };
                return __webpack_require__.d(getter, { a: getter }), getter;
            }),
            (__webpack_require__.d = function (exports, definition) {
                for (var key in definition)
                    __webpack_require__.o(definition, key) &&
                        !__webpack_require__.o(exports, key) &&
                        Object.defineProperty(exports, key, { enumerable: !0, get: definition[key] });
            }),
            (__webpack_require__.o = function (obj, prop) {
                return Object.prototype.hasOwnProperty.call(obj, prop);
            }),
            (__webpack_require__.r = function (exports) {
                'undefined' != typeof Symbol &&
                    Symbol.toStringTag &&
                    Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' }),
                    Object.defineProperty(exports, '__esModule', { value: !0 });
            }),
            (function () {
                var installedChunks = { 792: 0 };
                __webpack_require__.O.j = function (chunkId) {
                    return 0 === installedChunks[chunkId];
                };
                var webpackJsonpCallback = function (parentChunkLoadingFunction, data) {
                        var moduleId,
                            chunkId,
                            chunkIds = data[0],
                            moreModules = data[1],
                            runtime = data[2],
                            i = 0;
                        if (
                            chunkIds.some(function (id) {
                                return 0 !== installedChunks[id];
                            })
                        ) {
                            for (moduleId in moreModules)
                                __webpack_require__.o(moreModules, moduleId) &&
                                    (__webpack_require__.m[moduleId] = moreModules[moduleId]);
                            if (runtime) var result = runtime(__webpack_require__);
                        }
                        for (parentChunkLoadingFunction && parentChunkLoadingFunction(data); i < chunkIds.length; i++)
                            (chunkId = chunkIds[i]),
                                __webpack_require__.o(installedChunks, chunkId) &&
                                    installedChunks[chunkId] &&
                                    installedChunks[chunkId][0](),
                                (installedChunks[chunkId] = 0);
                        return __webpack_require__.O(result);
                    },
                    chunkLoadingGlobal = (self.webpackChunkContent = self.webpackChunkContent || []);
                chunkLoadingGlobal.forEach(webpackJsonpCallback.bind(null, 0)),
                    (chunkLoadingGlobal.push = webpackJsonpCallback.bind(
                        null,
                        chunkLoadingGlobal.push.bind(chunkLoadingGlobal),
                    ));
            })(),
            (__webpack_require__.nc = void 0);
        var __webpack_exports__ = __webpack_require__.O(void 0, [604], function () {
            return __webpack_require__(738);
        });
        return (__webpack_exports__ = __webpack_require__.O(__webpack_exports__)), __webpack_exports__;
    })();
});
